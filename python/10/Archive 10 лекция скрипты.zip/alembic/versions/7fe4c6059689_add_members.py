"""add members.

Revision ID: 7fe4c6059689
Revises:
Create Date: 2022-02-13 14:59:40.282075
"""
import sqlalchemy as sa

from alembic import op

# revision identifiers, used by Alembic.
revision = "7fe4c6059689"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
